﻿chartOptions['I.50.1.0011'] = {
    "series": [
        {
            "color": "#71A3B5",
            "index": 0,
            "legendIndex": 0 
        },
        {
            "color": "#FABD24",
            "index": 2,
            "legendIndex": 2 
        },
        {
            "color": "#8A8A8A",
            "index": 1,
            "legendIndex": 1 
        }        
  ],
  "xAxis": {
      "type": "category"
  }
};

 