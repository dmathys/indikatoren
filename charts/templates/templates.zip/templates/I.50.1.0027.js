chartOptions['I.50.1.0027'] = {
    "series": [
        {
            "color": "#256370",
            "index": 0,
            "legendIndex": 0 
        },
        {
            "color": "#FABD24",
            "index": 2,
            "legendIndex": 2 
        },
        {
            "color": "#8A8A8A",
            "index": 1,
            "legendIndex": 1 
        }        
  ],
  "xAxis": {
      "type": "category"
  },
};

 