chartOptions['I.50.1.0010'] = {
    "series": [
        {
            "color": "#256370",
            "index": 0,
            "legendIndex": 0 
        },
        {
            "color": "#71A3B5",
            "index": 1,
            "legendIndex": 1 
        },
        {
            "color": "#FFBB58",
            "index": 4,
            "legendIndex": 4 
        },
        {
            "color": "#FF8028",
            "index": 5,
            "legendIndex": 5 
        },
        {
            "color": "#C8C8C8",
            "index": 2,
            "legendIndex": 2 
        }        
  ],
  "xAxis": {
      "type": "category"
  }
};

 