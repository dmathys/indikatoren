chartOptions['I.50.4.0006'] = {
    "series": [
        {
            "color": "#71A3B5", 
            "index": 0            
        },
        {
            "color": "#FFBB58", 
            "index": 2
        },
        {
            "color": "#8A8A8A", 
            "index": 1
        }        
  ],
  "xAxis": {
      "type": "category"
  },
  "legend": {
      "reversed": true
  }
};

 