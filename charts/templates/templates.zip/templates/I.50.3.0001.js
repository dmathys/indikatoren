chartOptions['I.50.3.0001'] = {
    "series": [
        {
        "color": "#B475AB"
        },
        {
        "color": "#71A3B5"
        },
        {
        "color": "#FFBB58"
        },
        {
        "color": "#C8C8C8"
        },
        {
        "color": "#8A8A8A"
        }        
  ],
  "xAxis": {
      "type": "category"
  },
};

 