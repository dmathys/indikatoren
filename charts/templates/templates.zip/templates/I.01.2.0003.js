chartOptions['I.01.2.0003'] = {
	"series": [{
		"color": "#923F8D"
	}]
};

//Colors of StatA Bereiche: violett3 #923F8D, gruen3 #68AB2B, blau3 #689199