chartOptions['I.03.4.0003'] = {
	"series": [{
		"color": "#689199"
	}]
};

//Colors of StatA Bereiche: violett3 #923F8D, gruen3 #68AB2B, blau3 #689199