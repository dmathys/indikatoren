chartOptions['I.50.1.0025'] = {
    "series": [
        {
            "color": "#71A3B5"
        },
        {
            "color": "#FFBB58"
        },
        {
            "color": "#8A8A8A"
        }        
  ],
  "xAxis": {
      "type": "category"
  },
  "legend": {
      "reversed": false
  }
};

 