chartOptions['I.02.1.0016'] = {
	"series": [{
		"color": "#68AB2B"
	}]
};

//Colors of StatA Bereiche: violett3 #923F8D, gruen3 #68AB2B, blau3 #689199