﻿chartOptions['I.50.1.0005'] = {
  "xAxis": {
    "type": "category"
  },
  "series": [
    {
      "color": "#999999",
      "index": 2
    },
    {
      "color": "#dc440e",
      "index": 0
    },
    {
      "color": "#ffbb58",
      "index": 1
    },
    {
      "color": "#68ab2b",
      "index": 3
    },
    {
      "color": "#007a2f",
      "index": 4
    }
  ]
};
